document.querySelector("#tera.card").addEventListener("click", onclick);
function onclick() {
  location.href = "./tera.html";
  console.log("tera");
}
